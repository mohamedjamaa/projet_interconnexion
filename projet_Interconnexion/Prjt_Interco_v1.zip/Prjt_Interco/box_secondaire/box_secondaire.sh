#!/bin/bash

# Mise en marche du NAT (vérifier que c'est le bon port connecté au reste du réseau)
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE


# Mise en marche de OSPF
sed -i 's/ospfd=no/ospfd=yes/' etc/frr/daemons
cd usr/lib/frr 
./watchfrr zebra ospfd
cd ../../../

#Rajout des réseaux dans OSPF !!!!! NE FONCTIONNE PAS POUR RAISON OBSCURE !!!!!!!
vtysh -f /home/ospf.txt


while true; do sleep 1000;
done

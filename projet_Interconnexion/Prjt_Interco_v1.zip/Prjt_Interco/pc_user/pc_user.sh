#!/bin/ash

#On supprime la route par défaut
ip route del default

# On ajoute la box en tant que route par défaut
ip route add default via 192.168.1.2


while true; do sleep 1000;
done

#!/bin/bash

# NAT pour le serveur web et DNS
iptables -t nat -A POSTROUTING -o eth1 -j MASQUERADE


# Mise en marche de OSPF
sed -i 's/ospfd=no/ospfd=yes/' etc/frr/daemons
cd usr/lib/frr 
./watchfrr zebra ospfd
cd ../../../


while true; do sleep 1000;
done
